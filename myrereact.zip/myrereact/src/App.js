import React, { useState, useEffect } from 'react';
import './App.css';

const API_KEY = '91a7e1e01060b7b85def0bf894e5f0e2'; // Replace with your WeatherAPI key
const BASE_URL = 'http://api.weatherapi.com/v1';

const countries = [
  { name: 'USA', code: 'US' },
  { name: 'India', code: 'IN' },
  { name: 'Canada', code: 'CA' },
  // Add more countries and their codes as needed
];

const App = () => {
  const [selectedCountry, setSelectedCountry] = useState('');
  const [weatherData, setWeatherData] = useState(null);

  const fetchWeatherData = async (countryCode) => {
    try {
      const response = await fetch(`${BASE_URL}/forecast.json?key=${API_KEY}&q=${countryCode}&days=4`);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const data = await response.json();
      setWeatherData(data);
    } catch (error) {
      console.error('Error fetching weather data:', error);
    }
  };

  useEffect(() => {
    if (selectedCountry) {
      fetchWeatherData(selectedCountry);
    }
  }, [selectedCountry]);

  return (
    <div className="App">
      <h1>Weather Forecast</h1>
      <select
        value={selectedCountry}
        onChange={(e) => setSelectedCountry(e.target.value)}
        className="country-select"
      >
        <option value="">Select a country</option>
        {countries.map((country) => (
          <option key={country.code} value={country.code}>
            {country.name}
          </option>
        ))}
      </select>

      {weatherData && (
        <div className="weather-info">
          <div className="current-weather">
            <h2>Current Weather</h2>
            <img
              src={weatherData.current.condition.icon}
              alt={weatherData.current.condition.text}
              className="weather-icon"
            />
            <p>Temperature: {weatherData.current.temp_c}°C</p>
            <p>Condition: {weatherData.current.condition.text}</p>
          </div>

          <div className="forecast">
            <h2>Next 3 Days Forecast</h2>
            {weatherData.forecast.forecastday.slice(1).map((day) => (
              <div key={day.date} className="forecast-day">
                <h3>{day.date}</h3>
                <img
                  src={day.day.condition.icon}
                  alt={day.day.condition.text}
                  className="weather-icon"
                />
                <p>Temperature: {day.day.avgtemp_c}°C</p>
                <p>Condition: {day.day.condition.text}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
